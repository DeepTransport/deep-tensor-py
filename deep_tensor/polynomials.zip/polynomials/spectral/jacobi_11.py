import math

import torch 
from torch import Tensor 
from torch.distributions.beta import Beta

from .recurr import Recurr


class Jacobi11(Recurr):

    def __init__(
        self, 
        order: int, 
        device: torch.device = torch.device("cpu")
    ):
        k = torch.arange(order+1, device=device)
        a = (2*k+3) * (k+2) / (k+1) / (k+3)
        b = torch.zeros_like(k)
        c = (k+2)/(k+3)
        norm = ((2.0*k+3.0) * (k+2.0) / (8.0 * (k+1.0)) * (4.0/3.0)).sqrt()
        self.device = device
        Recurr.__init__(self, order, a, b, c, norm, self.device)
        return
    
    @property
    def weights(self) -> Tensor:
        return self._weights

    @property 
    def domain(self) -> Tensor:
        return torch.tensor([-1.0, 1.0], device=self.device)
    
    @property
    def constant_weight(self) -> bool:
        return False
    
    def sample_measure(self, n: int) -> Tensor:
        ls = Beta(2.0, 2.0).sample((n,)).to(self.device)
        ls = (2.0 * ls) - 1.0
        return ls
    
    def eval_measure(self, ls: Tensor) -> Tensor:
        ws = 0.75 * (1.0 - ls.square())
        return ws
    
    def eval_log_measure(self, ls: Tensor) -> Tensor:
        ws = (1.0 - ls.square()).log() + math.log(0.75)
        return ws
    
    def eval_measure_deriv(self, ls: Tensor) -> Tensor:
        ws = -1.5 * ls
        return ws
    
    def eval_log_measure_deriv(self, ls: Tensor) -> Tensor:
        raise NotImplementedError()